package com.ibm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;

public class CallInteropServlet {

	
	
	private static String getFindInventoryInput(){
		YFCDocument dPromise = YFCDocument.createDocument("Promise");
		YFCElement ePromise = dPromise.getDocumentElement();
		ePromise.setAttribute("OrganizationCode", "Aurora");
		YFCElement ePromiseLine = ePromise.getChildElement("PromiseLines", true).createChild("PromiseLine");
		ePromiseLine.setAttribute("ItemID", "AuroraWMDRS-003");
		ePromiseLine.setAttribute("LineId", "L1");
		ePromiseLine.setAttribute("UnitOfMeasure", "EACH");
		ePromiseLine.setAttribute("RequiredQty", "9999999");
		return dPromise.getString();
	}
	
	private static String getFindInventoryTemplate(){
		YFCDocument dPromise = YFCDocument.createDocument("Promise");
		YFCElement ePromise = dPromise.getDocumentElement();
		YFCElement eSuggestedOption = ePromise.createChild("SuggestedOption");
		YFCElement eOption = eSuggestedOption.createChild("Option");
		eOption.setAttribute("HasAnyUnavailableQty", "");
		eOption.setAttribute("OptionNo", "");
		eOption.setAttribute("NodeQty", "");
		eOption.setAttribute("AvailableFromUnplannedInventory", "");
		eOption.setAttribute("FirstDate", "");
		eOption.setAttribute("LastDate", "");
		YFCElement ePromiseLine = eOption.getChildElement("PromiseLines", true).createChild("PromiseLine");
		ePromiseLine.setAttribute("LineId", "");
		ePromiseLine.setAttribute("ItemID", "");
		ePromiseLine.setAttribute("ShipNode","");
		YFCElement eAssignment = ePromiseLine.getChildElement("Assignments", true).createChild("Assignment");
		eAssignment.setAttribute("DeliveryDate", "");
		eAssignment.setAttribute("EarliestShipDate", "");
		eAssignment.setAttribute("InvQty", "");
		eAssignment.setAttribute("InventoryAvailabilityDate", "");
		eAssignment.setAttribute("Quantity", "");
		eAssignment.setAttribute("ProcuredQty", "");
		eAssignment.setAttribute("ReservedQty", "");
		eAssignment.setAttribute("QuantityFromUnplannedInventory", "");
		eAssignment.setAttribute("ShipNode", "");
		eOption = ePromise.createChild("Option");
		eOption.setAttribute("HasAnyUnavailableQty", "");
		eOption.setAttribute("OptionNo", "");
		eOption.setAttribute("NodeQty", "");
		eOption.setAttribute("AvailableFromUnplannedInventory", "");
		eOption.setAttribute("FirstDate", "");
		eOption.setAttribute("LastDate", "");
		ePromiseLine = eOption.getChildElement("PromiseLines", true).createChild("PromiseLine");
		ePromiseLine.setAttribute("LineId", "");
		ePromiseLine.setAttribute("ItemID", "");
		eAssignment = ePromiseLine.getChildElement("Assignments", true).createChild("Assignment");
		eAssignment.setAttribute("DeliveryDate", "");
		eAssignment.setAttribute("EarliestShipDate", "");
		eAssignment.setAttribute("InvQty", "");
		eAssignment.setAttribute("InventoryAvailabilityDate", "");
		eAssignment.setAttribute("Quantity", "");
		eAssignment.setAttribute("ProcuredQty", "");
		eAssignment.setAttribute("ReservedQty", "");
		eAssignment.setAttribute("QuantityFromUnplannedInventory", "");
		eAssignment.setAttribute("ShipNode", "");
		return dPromise.getString();
		
	}
	public static void main(String[] args) {
		try {
			URL url = new URL("http://dublr047vm.dub.usoh.ibm.com:9080/smcfs/interop/InteropHttpServlet");
			URLConnection conn = url.openConnection();	
			conn.setDoOutput(true);
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
			out.write("YFSEnvironment.progId=");
            out.write(URLEncoder.encode("ProgId"));
            out.write('&');

            out.write("YFSEnvironment.adapterName=");
            out.write(URLEncoder.encode("adapterName"));
            out.write('&');

            out.write("YFSEnvironment.systemName=");
            out.write(URLEncoder.encode("systemName"));
            out.write('&');

            /*
             * TODO: Remove or expose... if (false) {
             * out.write("YFSEnvironment.rollbackOnly=");
             * out.write(URLEncoder.encode("Y")); out.write('&'); }
             */

            out.write("InteropApiName=");
            out.write(URLEncoder.encode("findInventory"));
            out.write('&');

            out.write("TemplateData=");
            out.write(URLEncoder.encode(getFindInventoryTemplate()));
            out.write('&');
            
            out.write("InteropApiData=");
            // InteropEnvHelper.getInstance().addEnvToDocument(envStub, apiName,
            // apiData, _props);        


            String apiString = URLEncoder.encode(getFindInventoryInput());
            out.write(apiString);

           /* if(_invokeAsService){
                out.write("IsFlow=");
                out.write(URLEncoder.encode("Y"));
                out.write('&');
            }*/

            out.flush();
            out.close();
            
            BufferedReader in = new BufferedReader (new InputStreamReader(conn.getInputStream()));
           
            StringBuffer sb = new StringBuffer();
            String response;
            while ((response = in.readLine()) != null){
            	sb.append(response);
            }
            in.close();
            System.out.println(YFCDocument.getDocumentFor(sb.toString()));
           
		} catch(MalformedURLException e){
			e.printStackTrace();
		} catch (IOException e){
			e.printStackTrace();
		}
		

	}

}
